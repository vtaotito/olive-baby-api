# 🚀 Guia de Deploy na VPS - Olive Assistant

## ✅ Status da Configuração

O arquivo `.env` foi configurado localmente com as variáveis necessárias para o AI Assistant:
- ✅ `OPENAI_API_KEY` configurada
- ✅ `OPENAI_MODEL=gpt-4o`
- ✅ `OPENAI_EMBEDDING_MODEL=text-embedding-3-small`
- ✅ `AI_MAX_TOKENS=2048`
- ✅ `AI_TEMPERATURE=0.7`
- ✅ `AI_RAG_TOP_K=6`

## 📋 Passos para Deploy na VPS

### 1. Conectar na VPS

```bash
ssh usuario@seu-servidor.com
```

### 2. Clonar/Atualizar Repositórios

```bash
# Backend
cd /caminho/para/olive-baby-api
git pull origin master

# Frontend (se necessário)
cd /caminho/para/olive-baby-web
git pull origin master
```

### 3. Configurar .env na VPS

Copie o arquivo `.env` local para a VPS ou crie um novo com as variáveis:

```bash
# Na VPS
cd /caminho/para/olive-baby-api
nano .env
```

**Variáveis obrigatórias:**
```env
# Database
DATABASE_URL=postgresql://olivebaby:SUA_SENHA@postgres:5432/olivebaby?schema=public
DB_USER=olivebaby
DB_PASSWORD=SUA_SENHA_SEGURA
DB_NAME=olivebaby

# Redis
REDIS_URL=redis://:SUA_SENHA_REDIS@redis:6379
REDIS_PASSWORD=SUA_SENHA_REDIS

# JWT (OBRIGATÓRIO - mínimo 32 caracteres)
JWT_ACCESS_SECRET=SUA_CHAVE_SECRETA_ACESSO_MIN_32_CARACTERES
JWT_REFRESH_SECRET=SUA_CHAVE_SECRETA_REFRESH_MIN_32_CARACTERES

# OpenAI (OBRIGATÓRIO para AI Assistant)
OPENAI_API_KEY=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
OPENAI_MODEL=gpt-4o
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
AI_MAX_TOKENS=2048
AI_TEMPERATURE=0.7
AI_RAG_TOP_K=6

# Frontend
FRONTEND_URL=https://app.olivebaby.com.br
VITE_API_URL=/api/v1

# SMTP (opcional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=seu-email@gmail.com
SMTP_PASS=sua-senha-app
```

### 4. Executar Deploy

**Opção A: Script Automatizado (Linux)**
```bash
cd /caminho/para/olive-baby-api
chmod +x deploy-ai.sh
./deploy-ai.sh --ingest
```

**Opção B: Manual**
```bash
cd /caminho/para/olive-baby-api

# 1. Build e start
docker compose -f docker-compose.vps.ai.yml up -d --build

# 2. Aguardar banco estar pronto
sleep 15

# 3. Rodar migrations
docker compose -f docker-compose.vps.ai.yml exec -T api npm run prisma:migrate:deploy

# 4. Indexar base de conhecimento
docker compose -f docker-compose.vps.ai.yml --profile ingest run --rm ai-ingest
```

### 5. Verificar Deploy

```bash
# Verificar containers
docker compose -f docker-compose.vps.ai.yml ps

# Verificar logs
docker compose -f docker-compose.vps.ai.yml logs -f api

# Health checks
curl http://localhost/health
curl http://localhost/api/v1/ai/health
```

### 6. Verificar Base de Conhecimento

```bash
# Conectar ao banco
docker compose -f docker-compose.vps.ai.yml exec postgres psql -U olivebaby -d olivebaby

# Verificar documentos indexados
SELECT COUNT(*) FROM ai_documents;
SELECT COUNT(*) FROM ai_chunks WHERE embedding IS NOT NULL;

# Deve retornar pelo menos 4 documentos e vários chunks
```

## 🔧 Troubleshooting

### Erro: "docker compose" não encontrado

Se estiver usando versão antiga do Docker:
```bash
# Use docker-compose (com hífen)
docker-compose -f docker-compose.vps.ai.yml up -d
```

### Erro: "pgvector extension not found"

Verifique se a imagem está correta:
```yaml
# No docker-compose.vps.ai.yml
postgres:
  image: pgvector/pgvector:pg16  # Deve ser esta imagem
```

### Erro: "OpenAI API key not configured"

Verifique se a variável está no `.env`:
```bash
grep OPENAI_API_KEY .env
```

### Erro: "No documents found" na ingestão

Verifique se os arquivos estão no lugar:
```bash
ls -la knowledge/
ls -la docs/
```

### Containers não iniciam

Verifique logs:
```bash
docker compose -f docker-compose.vps.ai.yml logs
```

## 📊 Verificação Pós-Deploy

### Checklist

- [ ] Containers rodando: `docker compose ps`
- [ ] API responde: `curl http://localhost/health`
- [ ] AI Health OK: `curl http://localhost/api/v1/ai/health`
- [ ] Frontend acessível: Abrir no navegador
- [ ] Base de conhecimento indexada: Verificar no banco
- [ ] Chat funciona: Testar em `/assistant`
- [ ] Insights aparecem: Verificar sidebar

## 🎯 Próximos Passos

1. ✅ Deploy completo
2. ✅ Base de conhecimento indexada
3. ⚠️ Configurar SSL/TLS (Let's Encrypt)
4. ⚠️ Configurar backup automático
5. ⚠️ Monitoramento (Sentry, DataDog)
6. ⚠️ Rate limiting ajustado conforme tráfego

## 📝 Notas

- O deploy pode levar 5-10 minutos na primeira vez (build das imagens)
- A ingestão da base de conhecimento pode levar 2-5 minutos
- Certifique-se de que as portas 80 e 443 estão abertas no firewall
- Para produção, configure SSL/TLS antes de expor publicamente
