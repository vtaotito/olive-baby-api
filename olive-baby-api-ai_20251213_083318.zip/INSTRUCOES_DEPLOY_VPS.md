# 📋 Instruções de Deploy na VPS - Passo a Passo

## ✅ Arquivos Preparados

Os seguintes arquivos foram criados e estão prontos para deploy:

1. **Backend (API)**: `olive-baby-api-ai_20251213_082547.zip`
   - Localização: `C:\Users\Vitor A. Tito\Documents\GPTO\OliverBaby\olive-baby-api\`
   - Contém: Todo o código backend + AI Assistant + docker-compose

2. **Frontend (Web)**: `olivebaby-web-ai-deploy-20251213_082629.zip`
   - Localização: `C:\Users\Vitor A. Tito\Documents\GPTO\OliverBaby\olive-baby-web\`
   - Contém: Todo o código frontend + AI Assistant + docker-compose

## 🚀 Como Fazer o Deploy

### Método 1: Via SSH (Recomendado)

#### Passo 1: Conectar na VPS

```bash
ssh usuario@oliecare.cloud
# ou use o IP da VPS
```

#### Passo 2: Preparar Ambiente

```bash
# Criar diretório
mkdir -p /docker/olive-baby
cd /docker/olive-baby
```

#### Passo 3: Upload dos Arquivos

**Do seu computador Windows (PowerShell):**

```powershell
# Backend
scp "C:\Users\Vitor A. Tito\Documents\GPTO\OliverBaby\olive-baby-api\olive-baby-api-ai_20251213_082547.zip" usuario@oliecare.cloud:/docker/olive-baby/

# Frontend  
scp "C:\Users\Vitor A. Tito\Documents\GPTO\OliverBaby\olive-baby-web\olivebaby-web-ai-deploy-20251213_082629.zip" usuario@oliecare.cloud:/docker/olive-baby/
```

#### Passo 4: Na VPS - Extrair Backend

```bash
cd /docker/olive-baby
unzip olive-baby-api-ai_20251213_082547.zip -d api/
cd api/
```

#### Passo 5: Configurar .env

```bash
nano .env
```

**Cole o conteúdo abaixo e ajuste as senhas:**

```env
NODE_ENV=production
PORT=4000
API_PREFIX=/api/v1

DATABASE_URL=postgresql://olivebaby:SUA_SENHA@postgres:5432/olivebaby?schema=public
DB_USER=olivebaby
DB_PASSWORD=SUA_SENHA_SEGURA
DB_NAME=olivebaby

REDIS_URL=redis://:SUA_SENHA_REDIS@redis:6379
REDIS_PASSWORD=SUA_SENHA_REDIS

JWT_ACCESS_SECRET=SUA_CHAVE_SECRETA_ACESSO_MIN_32_CARACTERES_AQUI
JWT_REFRESH_SECRET=SUA_CHAVE_SECRETA_REFRESH_MIN_32_CARACTERES_AQUI
JWT_ACCESS_EXPIRES_IN=1h
JWT_REFRESH_EXPIRES_IN=7d

FRONTEND_URL=https://oliecare.cloud

OPENAI_API_KEY=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
OPENAI_MODEL=gpt-4o
OPENAI_EMBEDDING_MODEL=text-embedding-3-small
AI_MAX_TOKENS=2048
AI_TEMPERATURE=0.7
AI_RAG_TOP_K=6
```

**Salve com Ctrl+O, Enter, Ctrl+X**

#### Passo 6: Executar Deploy do Backend

```bash
# Dar permissão de execução
chmod +x deploy-ai.sh

# Executar deploy com ingestão
./deploy-ai.sh --ingest
```

**Isso vai:**
1. Build das imagens Docker
2. Iniciar containers (postgres, redis, api, web, nginx)
3. Rodar migrations
4. Indexar base de conhecimento

#### Passo 7: Deploy do Frontend

```bash
cd /docker/olive-baby
unzip olivebaby-web-ai-deploy-20251213_082629.zip -d web/
cd web/

# Se necessário, build e deploy
docker compose -f docker-compose.yml up -d --build
```

#### Passo 8: Verificar

```bash
# Ver containers
docker compose -f docker-compose.vps.ai.yml ps

# Ver logs
docker compose -f docker-compose.vps.ai.yml logs -f

# Health check
curl http://localhost/health
curl http://localhost/api/v1/ai/health
```

### Método 2: Via SFTP/FTP

1. Use FileZilla, WinSCP ou similar
2. Conecte na VPS
3. Faça upload dos arquivos ZIP para `/docker/olive-baby/`
4. Siga os passos 4-8 acima

## 🔧 Comandos Úteis

```bash
# Ver status dos containers
docker compose -f docker-compose.vps.ai.yml ps

# Ver logs em tempo real
docker compose -f docker-compose.vps.ai.yml logs -f api

# Reiniciar um serviço
docker compose -f docker-compose.vps.ai.yml restart api

# Parar tudo
docker compose -f docker-compose.vps.ai.yml down

# Reindexar base de conhecimento
docker compose -f docker-compose.vps.ai.yml --profile ingest run --rm ai-ingest

# Acessar banco
docker compose -f docker-compose.vps.ai.yml exec postgres psql -U olivebaby -d olivebaby
```

## ⚠️ Importante

- **Senhas**: Altere todas as senhas no `.env` antes do deploy
- **JWT Secrets**: Use strings aleatórias de pelo menos 32 caracteres
- **Firewall**: Certifique-se de que as portas 80, 443 estão abertas
- **SSL**: Configure SSL/TLS após o deploy funcionar

## 🎉 Após o Deploy

Acesse:
- Frontend: `https://oliecare.cloud`
- API: `https://oliecare.cloud/api/v1`
- Assistant: `https://oliecare.cloud/assistant`
